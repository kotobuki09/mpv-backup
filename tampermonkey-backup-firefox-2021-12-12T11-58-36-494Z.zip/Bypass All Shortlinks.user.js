// ==UserScript==
// @name         Bypass All Shortlinks
// @namespace    Violentmonkey Scripts
// @version      9.0
// @description  Bypass All Shortlinks Sites Automatically Skips annoying link shorteners
// @author       Bloggerpemula
// @match      *://tech.dutchycorp.space/*
// @match      *://anime.dutchycorp.space/*
// @match      *://movies.dutchycorp.space/*
// @match      *://cool-time.dutchycorp.space/*
// @match      *://dutchycorp.space/s*/*
// @match      *://dutchycorp.ovh/s*/*
// @match      *://tmearn.com/*
// @match      *://droplink.co/*
// @match      *://tny.so/*
// @match      *://ouo.io/*
// @match      *://ouo.press/*
// @match      *://short.goldenfaucet.io/*
// @match      *://short.croclix.me/*
// @match      *://m.zolomix.com/*
// @match      *://makemoneywithurl.com/*
// @match      *://*.insuranceblog.xyz/*
// @match      *://coinsparty.mcrypto.club/*
// @match      *://sehati.xyz/*
// @match      *://rifurl.com/*
// @match      *://pennbookcenter.com/*
// @match      *://wordcounter.icu/*
// @match      *://publicananker.com/*
// @match      *://watchdoge.xyz/*
// @match      *://short.cryptolink.space/*
// @match      *://claimcoins.club/shortcoin/*
// @match      *://mikl4forex.com/*
// @match      *://michaelemad.com/*
// @match      *://miklpro.com/*
// @match      *://zoss.me/*
// @match      *://shrinke.me/*
// @match      *://clik.pw/*
// @match      *://zirof.com/*
// @match      *://arenaboard.xyz/*
// @match      *://newforex.online/*
// @match      *://forex-golds.com/*
// @match      *://nawahi1.com/*
// @match      *://mmo1s.com/*
// @match      *://passgen.icu/*
// @match      *://adshort.live/*
// @match      *://go.leolink.co/*
// @match      *://ccsl.xyz/*
// @match      *://xz2.xyz/*
// @match      *://bshopme.site/*
// @match      *://100count.net/*
// @match      *://fire-link.net/*
// @match      *://go.fire-link.net/*
// @match      *://bigb0ss.net/*
// @match      *://short.toptap.website/*
// @match      *://mcmcryptos.xyz/short/*
// @match      *://mitly.us/*
// @match      *://cashurl.in/*
// @match      *://linkad.in/*
// @match      *://linksly.co/*
// @match      *://bitcoinly.in/*
// @match      *://bitlinks.pw/*
// @match      *://owllink.net/*
// @match      *://mozlink.net/*
// @match      *://go.mozlink.net/*
// @match      *://neonlink.net/*
// @match      *://aii.sh/*
// @match      *://blog.earn4fun.in/*
// @match      *://iir.ai/*
// @match      *://*.5golink.com/*
// @match      *://yousm.link/*
// @match      *://forex-trnd.com/*
// @match      *://hoshilink.com/*
// @match      *://birdurls.com/*
// @match      *://bit-url.com/*
// @match      *://cuts-url.com/*
// @match      *://coinlyhub.com/*
// @match      *://popimed.com/*
// @match      *://phoenixshorts.com/*
// @match      *://short.clickscoin.com/*
// @match      *://url.namaidani.com/*
// @match      *://urlfiles.com/*
// @match      *://katflys.com/*
// @match      *://shrinkpay.xyz/*
// @match      *://bitcomarket.net/*
// @match      *://*.crazyblog.in/*
// @match      *://sl.claimfreebits.com/*
// @match      *://shortenbuddy.com/*
// @match      *://go.zolomix.in/*
// @match      *://wplink.online/*
// @match      *://arbweb.info/sl/*
// @match      *://sl.proinfinity.fun/*
// @match      *://icut.click/*
// @match      *://www.yofaurls.com/*
// @match      *://kiemlua.com/*
// @match      *://rodjulian.com/*
// @match      *://cryptofuns.ru/*
// @match      *://cashearn.cc/*
// @match      *://o.ovlinks.com/*
// @match      *://adfloz.co/*
// @match      *://shortlink.prz.pw/*
// @match      *://makeeasybtc.website/*
// @match      *://express-cut.ovh/*
// @match      *://uebnews.online/*
// @match      *://gobits.me/*
// @match      *://dogecoin.click/*
// @match      *://claimcrypto.cc/*
// @match      *://paid4.link/*
// @match      *://illink.net/*
// @match      *://kekolink.com/*
// @match      *://linkres.in/*
// @match      *://smoner.com/*
// @match      *://linkfly.io/*
// @match      *://coinadfly.com/*
// @match      *://coinshub.icu/*
// @match      *://mycut.my.id/*
// @match      *://zagl.info/*
// @match      *://shornet.com/*
// @match      *://jameeltips.us/*
// @match      *://genpassword.top/*
// @match      *://bitshort.co/*
// @match      *://gtlink.co/*
// @match      *://earnload.co/*
// @match      *://adfloz.co/*
// @match      *://*.snkra.com/*
// @match      *://clixshort.com/*
// @match      *://earnflies.com/*
// @match      *://*.fullreviews.org/*
// @match      *://c2g.at/*
// @match      *://urlty.com/*
// @match      *://clk.asia/*
// @match      *://adsgo.xyz/*
// @match      *://vshort.link/*
// @match      *://shrlink.top/*
// @match      *://sakastau.com/*
// @match      *://adsmoker.com/*
// @match      *://gainprofit.xyz/*
// @match      *://claimclicks.com/*
// @match      *://doctor-groups.com/*
// @match      *://url.acefaucet.com/*
// @match      *://earnwithshortlink.com/*
// @match      *://bitzite.com/*
// @match      *://m.imagenesderopaparaperros.com/*
// @match      *://link1s.com/*
// @match      *://gameen.xyz/*
// @match      *://fameen.xyz/*
// @match      *://yameen.xyz/*
// @match      *://link.sh2rt.com/*
// @match      *://noweconomy.live/*
// @match      *://deportealdia.live/*
// @match      *://techgeek.digital/*
// @match      *://sanoybonito.club/*
// @match      *://staaker.com/*
// @match      *://lucidcam.com/*
// @match      *://*.byboe.com/*
// @match      *://coinsparty.com/*
// @match      *://123link.biz/*
// @match      *://qualitystudymaterial.in/*
// @match      *://cutdl.xyz/*
// @match      *://cryptourl.net/*
// @match      *://ponselharian.com/*
// @match      *://marocclickers.xyz/*
// @match      *://cryptonetos.ru/page/redirect*
// @match      *://liinkat.com/*
// @match      *://landing.adly.fun/*
// @match      *://m.w4earn.com/*
// @match      *://mixespecialidades.live/*
// @match      *://thegoneapp.com/*
// @match      *://alocd.com/*
// @match      *://azsoft.biz/*
// @match      *://mobi2c.com/*
// @match      *://*.medcpu.com/*
// @match      *://*.nousdecor.com/*
// @match      *://t2l.one/*
// @match      *://sh2rt.com/*
// @match      *://link.rota.cc/*
// @match      *://world-trips.net/*
// @match      *://studyuo.com/*
// @match      *://speedynews.xyz/*
// @match      *://tecboy.xyz/*
// @match      *://blog.earn2fly.in/*
// @match      *://hookeaudio.com/*
// @match      *://fc-lc.com/*
// @match      *://fcc.lc/*
// @match      *://*.restorbio.com/*
// @match      *://expertvn.com/*
// @match      *://markipli.com/*
// @match       *://downphanmem.com/*
// @match       *://uebnews.online/*
// @match       *://kingsleynyc.com/*
// @match       *://yoshare.net/*
// @match       *://forex-gold.net/*
// @match       *://theicongenerator.com/*
// @match       *://cryptolatest.news/*
// @match       *://healthy4pepole.com/*
// @match       *://*.bdnewsx.com/*
// @match       *://techmody.io/*
// @match       *://girls-like.me/*
// @match       *://kiktu.com/*
// @match       *://*.upshrink.com/*
// @match       *://mynewsmedia.co/*
// @match       *://healdad.com/*
// @match       *://dataf.pro/*
// @match       *://marharo.com/*
// @match       *://ez4mods.com/*
// @match       *://try2link.com/*
// @match       *://ex-foary.com/*
// @match       *://automotur.club/*
// @match       *://wp.womenhaircolors.review/*
// @match       *://money.alyoumeg.com/*
// @match       *://dogeearn.com/*
// @match       *://topcryptoz.net/*
// @match       *://allcryptoz.net/*
// @match       *://blogginglass.com/*
// @match       *://uniqueten.net/*
// @match       *://www.ultraten.net/*
// @match       *://www.gifans.com/*
// @match       *://wpking.in/*
// @match       *://mcrypto.club/*
// @match       *://insuranceblog.xyz/*
// @match       *://amazingdarpon.com/*
// @match       *://petslots.website/*
// @match       *://blog.bshopme.site/*
// @match       *://palpodcast.site/*
// @match       *://lensabicara.com/*
// @match       *://tieutietkiem.com/*
// @match       *://claimsatoshi.co/*
// @match       *://bittalky.com/*
// @match      *://urlily.com/*
// @match      *://bablyfeed.com/*
// @match      *://jardima.com/*
// @match      *://kimo.ma/*
// @match      *://foodma.in/*
// @match      *://*.netfile.cc/*
// @match      *://7apple.net/*
// @match      *://saqercoin.xyz/*
// @match      *://store.filmyzilla-in.xyz/*
// @match      *://cryptotyphoon.com/short/*
// @match      *://ls2earn.in/*
// @match      *://coinsurl.com/*
// @match      *://bitcoin-indo.com/*
// @match      *://coin.mg/*
// @match      *://infinityfreescripts.xyz/*
// @match      *://*.technologylover.in/*
// @match      *://streamshort.in/*
// @match      *://*.urbharat.xyz/*
// @match      *://cafenau.com/*
// @match      *://techacode.com/*
// @match      *://link.encyclopedia-24.com/*
// @match      *://clickscoin.com/shortccsl/*
// @match      *://dogeclick.net/ccsl/*
// @match      *://adshort.space/*
// @match      *://flylink.site/*
// @match      *://cutearn.xyz/*
// @match      *://starfaucet.net/sl/*
// @match      *://ls2earn.com/*
// @match      *://safelink.site/*
// @match      *://zipcrypto.site/*
// @match      *://cutgo.site/*
// @match      *://cutbits.site/*
// @match      *://shorthero.site/*
// @match      *://sl-1.btcbunch.com/*
// @match      *://sl-2.btcbunch.com/*
// @match      *://sl-3.btcbunch.com/*
// @match      *://sl-1.askpaccosi.com/*
// @match      *://sl-2.askpaccosi.com/*
// @match       *://foodyrecipe.xyz/*
// @match       *://redir.123file.li/*
// @match       *://sevenjournals.com/*
// @match       *://android-mody.store/*
// @match       *://mercedesellington.com/*
// @match       *://blog.crypto-faucet.xyz/*
// @match       *://7misr4day.com/*
// @match       *://sama-pro.com/*
// @match       *://samaa-pro.com/*
// @match       *://imageresizertool.com/*
// @match       *://*.jobswd.com/*
// @match       *://techrfour.com/*
// @match       *://ovavibe.net/*
// @match       *://zshort.cc/*
// @match       *://m.bdnewsx.com/*
// @match       *://freebitcoin.vip/*
// @match       *://freelitecoin.vip/*
// @match       *://toptechtalk.xyz/*
// @match       *://ez4short.com/*
// @match       *://ccurl.net/*
// @match      *://cslink.in/*
// @match      *://faucet.100count.net/*
// @match      *://short-cash2.xyz/*
// @match      *://topnewsnew.com/*
// @match      *://gawishpro.com/*
// @match      *://ad-mezo.com/*
// @match      *://th3dz.com/sl/*
// @match      *://kooza.club/*
// @match      *://dz4link.com/*
// @match       *://coinbaze.in/*
// @match      *://atlai.club/*
// @match      *://adcrypto.co/claim/*
// @match      *://skincarie.com/*
// @match      *://cryptocoinearn.xyz/*
// @match      *://11bit.co.in/bitshort/*
// @match      *://cryptofans.club/short/*
// @match      *://phoenixfaucets.xyz/short/*
// @match      *://dragonfaucets.xyz/short/*
// @match       *://1ist.club/*
// @match       *://earnads.top/*
// @match       *://short.phoenixfaucets.xyz/*
// @match       *://phoenixfaucets.xyz/next/*
// @match       *://phoenixfaucets.xyz/secret/*
// @match       *://phoenixfaucets.xyz/step1/*
// @match       *://phoenixfaucets.xyz/step2/*
// @match       *://phoenixfaucets.xyz/step3/*
// @match       *://phoenixfaucets.xyz/step4/*
// @match       *://cryptofans.club/next/*
// @match       *://cryptofans.club/other/*
// @match       *://cryptofans.club/step1/*
// @match       *://cryptofans.club/step2/*
// @match       *://cryptofans.club/step3/*
// @match       *://cryptofans.club/step4/*
// @match       *://short.mcmcryptos.xyz/*
// @match      *://shurt.pw/*
// @match      *://okrzone.com/*
// @match      *://downfile.site/*
// @match      *://scratch247.info/*
// @match      *://yalla-shoot-now.us/*
// @match      *://sl.mcmfaucets.xyz/*
// @match      *://clickscoin.com/short/*
// @match      *://dogeclick.net/short/*
// @match      *://mcrypto.club/*
// @match      *://crypto-faucet.xyz/*
// @match      *://dogemate.com/*
// @match      *://luckydice.net/*
// @match      *://coinsearns.com/*
// @match      *://dogeearn.com/*
// @match      *://luckybits.online/*
// @match      *://sakastau.com/*
// @match      *://didhafairus.my.id/*
// @match      *://go.safeadlink.my.id/*
// @match      *://short-zero.com/*
// @match      *://nex-url.cyou/*
// @match      *://exey.io/*
// @match      *://clk.ink/*
// @match      *://cryptoads.space/*
// @match      *://infinitycoupon.com/*
// @match      *://zcpa.us/*
// @match      *://*.adz7short.space/*
// @match      *://za.gl/*
// @match      *://tei.ai/*
// @match      *://shon.xyz/*
// @match      *://linkmit.us/*
// @match      *://link1s.net/*
// @match      *://bestshort.xyz/*
// @match      *://toptap.website/short/*
// @match      *://links.doctorcoin.xyz/*
// @match      *://*.softairbay.com/shortSAB/*
// @match      *://adnit.xyz/*
// @match      *://earncoin.site/*
// @match      *://mfk-shorter.com/*
// @match      *://donnaleehunt.com/*
// @match      *://*.imperialstudy.com/*
// @match      *://bildirim.eu/ph/*
// @match      *://aylink.co/*
// @match      *://kiiw.icu/*
// @grant      none
// @license    MIT
// @run-at     document-end
// ==/UserScript==

(function() {
    'use strict';
    const elementExists = query => document.querySelector(query) !== null;
    const clickIfElementExists = (query, timeInSec = 1, funcName = 'setTimeout') => {
        if (elementExists(query)) {
            console.log(document.querySelector(query))
            window[funcName](function() {
                document.querySelector(query).click();
            }, timeInSec * 1000);
        }
    }

    if (elementExists("#link-view")) {
        const a = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("#link-view").submit();
                clearInterval(a);
            }
        }, 500);
    }

    if (elementExists("#adb-not-enabled > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > form:nth-child(1)")) {
        const b = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("#adb-not-enabled > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > form:nth-child(1)").submit();
                clearInterval(b);
            }
        }, 500);
    }

    if (elementExists(".m-2.btn-captcha.btn-outline-primary.btn")) {
        const c = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector(".m-2.btn-captcha.btn-outline-primary.btn").click();
                clearInterval(c);
            }
        }, 500);
    }

    if (elementExists("button#continue.btn.btn-primary.btn-captcha")) {
        const d = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("button#continue.btn.btn-primary.btn-captcha").click();
                clearInterval(d);
            }
        }, 500);
    }

    if (elementExists("#userForm")) {
        const e = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("#userForm").submit();
                clearInterval(e);
            } else {
                document.querySelector("#cbt").click();
            }
        }, 500);
    }

    if (elementExists("#lview > form")) {
        const f = setInterval(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("#lview > form").submit();
                clearInterval(f);
            }
        }, 500);
    }

    if (elementExists(".yu-blue.yu-btn")) {
        setTimeout(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector(".yu-blue.yu-btn").click();
            }
        }, 500);
    }

    if (elementExists("wpsafe-snp")) {
        setTimeout(function() {
            if (window.grecaptcha.getResponse().length > 0) {
                document.querySelector("wpsafe-snp").submit()
            }
        }, 2000);
    }

    // ============================================
    // SetTimeout
    // ============================================
    clickIfElementExists('button#btn6.yu-btn.yu-go')
    clickIfElementExists('.btn-ml.btn-primary.btn')
    clickIfElementExists('a#firststep-btn.btn.btnstep1')
    clickIfElementExists('a#finalx22.btn.btnstep1')
    clickIfElementExists('#url_qu > a:nth-child(1)')
    clickIfElementExists('#wpsafelinkhuman > img:nth-child(1)')
    clickIfElementExists('div.box-main:nth-child(2) > div:nth-child(4) > a:nth-child(1)')
    clickIfElementExists('#links > a:nth-child(2) > center:nth-child(1) > img:nth-child(1)')
    clickIfElementExists('#links > form:nth-child(2) > button:nth-child(3) > img:nth-child(1)')
    clickIfElementExists('button#btn6.g-recaptcha.btn.btn-primary')
    clickIfElementExists('button#btn6.btn.btn-outline-primary.btn-captcha.m-2')
    clickIfElementExists('button#submit-button.btn.btn-primary')
    clickIfElementExists('div#mainlink.h_mnm.h_count a.s-btn-f')
    clickIfElementExists('#link1s-snp > button:nth-child(1)')
    clickIfElementExists('button#link.btn.btn-primary')
    clickIfElementExists('button.btn-main.get-link')
    // 2 Sec
    clickIfElementExists('.next-button.btn-lg.text-white.btn-info.btn', 2)
    clickIfElementExists('.next-button.text-white.btn-info.btn', 2)
    clickIfElementExists('.btn-outline-white.btn', 2)
    // 3 Sec
    clickIfElementExists('button#btn-main.btn.btn-main', 3)
    clickIfElementExists('button#btn-get-link', 3)
    clickIfElementExists('.col-md-8 > form:nth-child(17) > button:nth-child(3)', 3)
    clickIfElementExists('#cl1 > center:nth-child(1) > a:nth-child(1)', 3)
    clickIfElementExists('div#wpsafe-generate a img', 3)
    clickIfElementExists('.btn-danger.btn-raised.btn', 3)
    clickIfElementExists('.btn-danger.btn-raised', 3)
    clickIfElementExists('a.submitBtn.btn.btn-primary', 3)
    clickIfElementExists('button#submitbtn.g-recaptcha.btn.btn-primary', 3)
    clickIfElementExists('p.getlink', 3)
    clickIfElementExists('button#getlink.getlink.disabled', 3)
    clickIfElementExists('#link1s-snp > button:nth-child(1)', 3)
    clickIfElementExists('#cl1 > a:nth-child(2) > font:nth-child(1)', 3)
    clickIfElementExists('button#mdt.custom-btn.btn-7', 3)
    clickIfElementExists('input.btn.btn-primary', 3)
    clickIfElementExists('input#btn-main.btn.btn-primary', 3)
    clickIfElementExists('#cl1 > a:nth-child(1) > font:nth-child(1) > b:nth-child(1)', 3)
    // 5 Sec
    clickIfElementExists('div.complete a.btn', 5)
    clickIfElementExists('div#makingdifferenttimer', 5)
    clickIfElementExists('div#wpsafe-link a img', 5)
    clickIfElementExists('#wpsafe-snp > a:nth-child(1)', 5)
    clickIfElementExists('#wpsafe-snp > center:nth-child(1) > a:nth-child(1)', 5)
    clickIfElementExists('a#surl1.btn-main.get-link', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn-main.get-link', 5)
    clickIfElementExists('.btn-captcha.btn-sm.btn-primary.btn', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.ybtn.ybtn-accent-color.btn-captcha', 5)
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.btn-outline-primary.btn-lg.btn-block.btn-captcha', 5)
    // 7 Sec
    clickIfElementExists('button#invisibleCaptchaShortlink.btn.btn-primary.btn-goo.btn-captcha', 7)
    clickIfElementExists('button#get_link.btn.btn-primary.btn-sm', 7)
    clickIfElementExists('button.btn.btn-success', 7)
    // 9 Sec
    clickIfElementExists('div.lds-ellipsis', 9)

    if (elementExists('#before-captcha')) {
        setTimeout(function() {
            document.querySelector('#before-captcha').submit();
        }, 3000);
    }

    if (elementExists('a#firststep-btn.btn.btnstep1')) {
        setTimeout(function() {
            document.querySelector('button#getlink.btn.m-2.btn-success.disabled').click();
        }, 3000);
    }
    // ============================================
    // setInterval
    // ============================================
    // 1 Sec
    clickIfElementExists('.yu-blue.yu-btn', 1, 'setInterval')

    // 3 Sec

    clickIfElementExists('a.get-link.bg-red-600.px-8.py-2.rounded-md.inline-block', 3, 'setInterval')
    clickIfElementExists('input.g-recaptcha.btn.btn-primary', 3, 'setInterval')
    clickIfElementExists('.get-link.ybtn-accent-color.ybtn.btn', 3, 'setInterval')
    // 5 Sec
    clickIfElementExists('#go_d', 5, 'setInterval')
    clickIfElementExists('div.skip-ad a.btn', 5, 'setInterval')
    clickIfElementExists('.btn-success.m-2.btn', 5, 'setInterval')
    clickIfElementExists('button.btn-block.btn-success', 5, 'setInterval')
    clickIfElementExists('.get-link.btn-lg.btn-success.btn', 5, 'setInterval')
    clickIfElementExists('.get-link.btn-lg.btn-primary.btn', 5, 'setInterval')
    clickIfElementExists('a.btn.btn-primary.get-link.text-white', 5, 'setInterval')
    clickIfElementExists('a.btn-main.get-link', 5, 'setInterval')
    clickIfElementExists('#ytimer > .s-btn-f', 5, 'setInterval')
    clickIfElementExists('#yuidea-btn > .m-2.btn-captcha.btn-outline-primary.btn', 5, 'setInterval')
    clickIfElementExists('#btn6.btn-captcha.btn-primary.btn', 5, 'setInterval')
    clickIfElementExists('#cbt.btn-primary.btn-warningbtn.btn', 5, 'setInterval')

  // Old Codes
if(window.location.hostname== ('toptechtalk.xyz','atlai.club')){setInterval(function() { document.querySelector('#cbt.btn-primary.btn-warningbtn.btn').click(); }, 3000);}
if(window.location.hostname== 'markipli.com'){setInterval(function() { document.querySelector('.btn-success.m-2.btn').click(); }, 5000);}


  if(window.location.hostname== ('goldenfaucet.io','croclix.me')) {
        let $ = window.jQuery;

        function fireMouseEvents(query) {
            const element = document.querySelector(query);
            if (!element) return;
            ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(eventName => {
                if (element.fireEvent) {
                    element.fireEvent('on' + eventName);
                } else {
                    const eventObject = document.createEvent('MouseEvents');
                    eventObject.initEvent(eventName, true, false);
                    element.dispatchEvent(eventObject);
                }
            })
        }

        setInterval(function() {
            if ($("#link").length > 0) {
                fireMouseEvents("#link")
            }
        }, 500);
        setTimeout(function() {
            if ($("input#continue").length > 0) {
                fireMouseEvents("input#continue");
            }
            if ($("a#continue.button").length > 0) {
                fireMouseEvents("a#continue.button")
            }
        }, 9000);
        setTimeout(function() {
            if ($("#btn-main").length < 0) return;
            fireMouseEvents("#btn-main")
        }, 5000);
    }
})();