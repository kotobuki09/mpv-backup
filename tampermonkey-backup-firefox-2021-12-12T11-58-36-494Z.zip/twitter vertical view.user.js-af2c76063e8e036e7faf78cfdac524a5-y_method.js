// ==UserScript==
// @name         y_method
// @version      0.1.3
// @description  ちょっとした機能
// @author       y_kahou
// ==/UserScript==

/**
 * スタイルを追加する
 * @param id {string} - スタイルのID
 * @param css {string} - css本体
 */
function addStyle(id, css) {
    var style = document.createElement('style')
    style.id = id
    style.type = 'text/css'
    style.textContent = css
    document.querySelector('head').appendChild(style)
}
/**
 * 対象までスクロールせずにクリックする
 * @param selector {string} - 取得対象のセレクタ
 */
function click_(element) {
    var x = window.scrollX, y = window.scrollY
    element.click()
    window.scrollTo(x, y)
}
/**
 * 対象までスクロールせずにフォーカスする
 * @param selector {string} - 取得対象のセレクタ
 */
function focus_(element) {
    var x = window.scrollX, y = window.scrollY
    element.focus()
    window.scrollTo(x, y)
}
/**
 * 対象のdomを取得できるまで取得を挑戦する
 * @param selector {string} - 取得対象のセレクタ
 * @param interval {number} - 次の挑戦までの時間ms
 * @param repeat   {number} - 繰り返し回数
 */
function repeatGetElements(selector, interval = 500, repeat = 60) {
    return new Promise(function(resolve, reject) {
        var cnt = 0
        var it = setInterval(function() {
            if (++cnt > 60) {
                clearInterval(it)
                reject("Could'n get " + selector)
            }
            var ret = document.querySelectorAll(selector)
            if (ret.length > 0) {
                clearInterval(it)
                resolve(ret)
            }
        }, interval)
    })
}
/**
 * async関数内で使えるwait
 */
function wait(ms = 100) {
    return new Promise(function(resolve, reject) {
        setTimeout(() => resolve(), ms)
    })
}
/**
 * src込みのvideo要素の取得
 */
async function getVideo(selector = 'video') {
    var video
    for (var i = 0; i < 60; i++) {
        video = await repeatGetElements(selector)
        if (video[0].getAttribute('src'))
            break
        await wait(500)
    }
    return video 
}

/**
 * ファイル名に使えない文字を半角から全角へ変換する
 * @param name {string} - ファイル名
 */
function filenameEscape(name) {
    const target = ['\\', '/', ':', '*', '?', '"', '<', '>', '|', ]
    const rep = ['＼', '／', '：', '＊', '？', '”', '＜', '＞', '｜', ]
    let ename = name
    for (let i = 0; i < target.length; i++) {
        ename = ename.replaceAll(target[i], rep[i])
    }
    return ename
}

if (window.jQuery) (function($) {
    /**
     * 対象までスクロールせずにクリックする
     */
    $.fn.click_ = function() {
        click_(this[0])
        return this
    }
    /**
     * 対象までスクロールせずにフォーカスする
     */
    $.fn.focus_ = function() {
        focus_(this[0])
        return this
    }
})(window.jQuery);