// ==UserScript==
// @name        Recaptcha Auto 
// @namespace   Violentmonkey Scripts
// @match      *://*/recaptcha/api2/*
// @match      *://*.dutchycorp.ovh/*
// @match      *://*.dutchycorp.space/*
// @grant       none
// @version     1.3
// @author      Bloggerpemula
// @description Recaptcha Auto click ,if you have good IP Captcha will solve Automatically 
// ==/UserScript==

(function() {
    'use strict';

if(window.location.hostname==("dutchycorp.space") != -1 || window.location.hostname==("dutchycorp.ovh") != -1 ){
var ticker = setInterval(function(){
    try{
        grecaptcha.execute();
        clearInterval(ticker);
    } catch(e) {}
},2000);
}else {}

if (document.querySelector('.recaptcha-checkbox-border') !== null) {setTimeout(function() { document.querySelector('.recaptcha-checkbox-border').click(); }, 2000);}else {}


})();return;