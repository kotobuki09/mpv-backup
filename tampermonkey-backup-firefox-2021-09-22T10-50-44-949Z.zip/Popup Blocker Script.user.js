// ==UserScript==
// @name         Popup Blocker Script
// @name:zh-CN   弹窗阻止程序脚本
// @namespace    https://popupblockerscript.com/
// @version      0.8.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:zh-CN 用于阻止所有类型弹窗的最有效用户脚本。为防范最狡猾的弹窗而设计，包括成人和流媒体网站上的弹窗。
// @author       Mike Kyshenko
// @match        https://*/*
// @match        http://*/*
// @grant GM_listValues
// @grant GM_deleteValue
// @grant GM_setValue
// @grant GM_getValue
// @grant GM_getResourceURL
// @grant GM_getResourceText
// @grant GM_addStyle
// @grant GM_xmlhttpRequest
// @connect     re.popupblockerscript.com
// @connect     self
// @connect     *
// ==/UserScript==
