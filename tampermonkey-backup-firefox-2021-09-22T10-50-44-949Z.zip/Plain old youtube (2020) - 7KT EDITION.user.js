// ==UserScript==
// @name        Plain old youtube (2020) | 7KT EDITION
// @namespace gjwse90gj98we
// @version 2.7.8.1
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author 7KT-SWE
// @license      GPL-3.0-only
// @contributionURL https://www.paypal.com/donate/?hosted_button_id=2EJR4DLTR4Y7Q
// @include      https://*.youtube.com/*
// @include      https://*.youtube-nocookie.com/*
// @exclude      https://www.youtube.com/*/*.xml*
// @exclude      https://www.youtube.com/error
// @match *://*.youtube.com/*
// @match *://*.youtu.be/*
// @grant        GM_getResourceText
// @grant        GM_getResourceURL
// @grant        GM_addValueChangeListener
// @grant        GM_removeValueChangeListener
// @grant GM_addStyle
// @grant GM_getValue
// @grant GM_setValue
// @grant GM_listValues
// @grant GM_deleteValue
// @grant GM_registerMenuCommand
// @grant unsafeWindow
// @run-at document-start
// @compatible Chrome >=55 + Tampermonkey + Violentmonkey
// @compatible Firefox >=56 + Tampermonkey + Violentmonkey
// @compatible Opera + Tampermonkey + Violentmonkey
// @compatible Edge + Tampermonkey + Violentmonkey
// ==/UserScript==
