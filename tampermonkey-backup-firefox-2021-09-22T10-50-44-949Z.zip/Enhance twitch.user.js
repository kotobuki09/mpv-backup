// ==UserScript==
// @name         Enhance twitch
// @namespace    http://tampermonkey.net/
// @version      2.0.2
// @description  Show images/video in chat, always source quality, Auto click claim bonus, hide offline channels and more
// @author       Bum
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// @match        https://www.twitch.tv/*
// @match https://clips.twitch.tv/*
// @grant        none
// ==/UserScript==

var displayImages = "true";
var displayVideos = "true";
var autoPlayClips = "false";
var hideHypeTrain = "false";
var hideBitGiftLeaderBoard = "false";
var hideUnfollowButton = "false";
var ultraWide = "true";
var hideOfflineChannels = "true";
var hideRecommendedChannels = "true";
var hideTags = "false";
var hideSubscribeText = "false";
var alwaysSourceQuality = "true";
var hideFriendsList = "false";
var hideTheseThots = "false";

if (localStorage.getItem("hideSubscribeText") != null) {
    hideSubscribeText = localStorage.getItem("hideSubscribeText");
}
if (localStorage.getItem("hideTheseThots") != null) {
    hideTheseThots = localStorage.getItem("hideTheseThots");
}
if (localStorage.getItem("alwaysSourceQuality") != null) {
    alwaysSourceQuality = localStorage.getItem("alwaysSourceQuality");
}
if (localStorage.getItem("hideRecommendedChannels") != null) {
    hideRecommendedChannels = localStorage.getItem("hideRecommendedChannels");
}
if (localStorage.getItem("hideFriendsList") != null) {
    hideFriendsList = localStorage.getItem("hideFriendsList");
}
if (localStorage.getItem("hideTags") != null) {
    hideTags = localStorage.getItem("hideTags");
}

if (localStorage.getItem("displayImages") != null) {
    displayImages = localStorage.getItem("displayImages");
}
if (localStorage.getItem("hideOfflineChannels") != null) {
    hideOfflineChannels = localStorage.getItem("hideOfflineChannels");
}
if (localStorage.getItem("displayVideos") != null) {
    displayVideos = localStorage.getItem("displayVideos");
}
if (localStorage.getItem("autoPlayClips") != null) {
    autoPlayClips = localStorage.getItem("autoPlayClips");
}
if (localStorage.getItem("hideHypeTrain") != null) {
    hideHypeTrain = localStorage.getItem("hideHypeTrain");
}
if (localStorage.getItem("hideBitGiftLeaderBoard") != null) {
    hideBitGiftLeaderBoard = localStorage.getItem("hideBitGiftLeaderBoard");
}
if (localStorage.getItem("hideUnfollowButton") != null) {
    hideUnfollowButton = localStorage.getItem("hideUnfollowButton");
}

if (localStorage.getItem("ultraWide") != null) {
    ultraWide = localStorage.getItem("ultraWide");
}

if (ultraWide == "true"){

    GM_addStyle(".common-centered-column{    max-width: 100%;}");
}

GM_addStyle('.oHwVV::after {    content: "";    display: block;    position: absolute;    top: 0.2rem;    bottom: 0.2rem;    left: 0.2rem;    width: 1.2rem;    height: 1.2rem;    transition-property: left;    transition-timing-function: ease;    transition-duration: var(--timing-short);    border-radius: var(--border-radius-rounded);    background-color: var(--color-background-toggle-handle);}');

    GM_addStyle('.ScToggleInput-sc-796zbf-1:checked + .oHwVV::after {    content: "";    left: calc((100% - 1.2rem) - 0.2rem);    background-color: var(--color-background-toggle-checked);}');
    GM_addStyle('.ScToggleInput-sc-796zbf-1:checked + .oHwVV::before {    border-width: 0px 0px 2px 2px;    border-style: solid;    border-color: var(--color-text-toggle-checked-icon);    display: block;    position: absolute;    top: 0.7rem;    left: 0.8rem;    width: 0.7rem;    height: 0.3rem;    transform: translate3d(-50%, -50%, 0px) rotate(-45deg);    content: "";}');

    GM_addStyle('.oHwVV {    display: inline-block;    position: relative;    order: 0;    width: 3.5rem;    height: 2rem;    content: "";    cursor: pointer;    vertical-align: bottom;    border-width: 2px;    border-style: solid;    border-radius: 1rem;    transition-property: background-color;    transition-timing-function: ease;    transition-duration: var(--timing-short);    border-color: var(--color-border-toggle);    background-color: var(--color-background-toggle);}');

    GM_addStyle('.ScToggleInput-sc-796zbf-1:checked + .oHwVV {    border-color: var(--color-border-toggle-checked);}');


    GM_addStyle('.xAfNg {    display: flex !important;    -webkit-box-align: center !important;    align-items: center !important;}');
    GM_addStyle('.fjMXDc {    -webkit-box-flex: 1 !important;    flex-grow: 1 !important;    margin-right: 2rem !important;}');
    GM_addStyle('.kCtfmS {    display: flex;    position: relative;    flex-direction: column;    line-height: 2rem;}');
    GM_addStyle('.doVmsZ {    position: absolute;    opacity: 0;}');

function GM_addStyle(css) {
    const style = document.getElementById("GM_addStyle") || (function() {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.id = "GM_addStyle";
        document.head.appendChild(style);
        return style;
    })();
    const sheet = style.sheet;
    sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
}

function hideSubButton(){

    let btnSub = $('button[data-a-target="subscribe-button"]');
    if (btnSub.length ==0)
        btnSub = $('button[data-a-target="subscribed-button"]');
    var isReady = btnSub.length > 0;
    if (!isReady) {
        setTimeout(hideSubButton, 300);
        return;
    }

    btnSub.find(".tw-mg-l-05").attr("style","display: none !important");
    btnSub.find('div[data-a-target="tw-core-button-label-text"]').attr("style","display: none !important");
}
$( window ).on( "load", function() {
    if (hideTags == "true")
        $(".tw-tag").attr("style","display:none !important");
    if(hideSubscribeText == "true"){
        hideSubButton();
    }
    AlwaysSourceQuality();
});

function AlwaysSourceQuality(){
    var hidden, state, visibilityChange;
    if (typeof document.hidden !== "undefined") {
        hidden = "hidden";
        visibilityChange = "visibilitychange";
        state = "visibilityState";
    } else if (typeof document.mozHidden !== "undefined") {
        hidden = "mozHidden";
        visibilityChange = "mozvisibilitychange";
        state = "mozVisibilityState";
    } else if (typeof document.msHidden !== "undefined") {
        hidden = "msHidden";
        visibilityChange = "msvisibilitychange";
        state = "msVisibilityState";
    } else if (typeof document.webkitHidden !== "undefined") {
        hidden = "webkitHidden";
        visibilityChange = "webkitvisibilitychange";
        state = "webkitVisibilityState";
    }
    if (alwaysSourceQuality == "true")
    {
        Object.defineProperty(document, hidden, {value: false, writable: false});
        Object.defineProperty(document, state, {value: 'visible', writable: false});
        document.addEventListener(visibilityChange, function(e) {
            window.localStorage.setItem('s-qs-ts', Math.floor(Date.now()));
            window.localStorage.setItem('video-quality', '{"default":"chunked"}');
            e.stopImmediatePropagation();
        }, false);
    }
    else{
        delete document[hidden];
        delete document[state];
    }
}

jQuery(function($) {

  var _oldShow = $.fn.show;

  $.fn.show = function(speed, oldCallback) {
    return $(this).each(function() {
      var obj         = $(this),
          newCallback = function() {
            if ($.isFunction(oldCallback)) {
              oldCallback.apply(obj);
            }
            obj.trigger('afterShow');
          };


      // now use the old function to show the element passing the new callback
      _oldShow.apply(obj, [speed, newCallback]);
    });
  }
});

function RemoveCssRule(css) {
    const style = document.getElementById("GM_addStyle") || (function() {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.id = "GM_addStyle";
        document.head.appendChild(style);
        return style;
    })();
    const sheet = style.sheet;
    for (var i=0; i<sheet.cssRules.length; i++) {
        if (sheet.cssRules[i].selectorText == css) {
            sheet.deleteRule (i);
        }
    }
}

function LoadTwitchEnhance(){
    $('body').click(function(evt){
        $(".fixMenuAppended").removeClass("fixMenuAppended");
    });
    var config = { attributes: false, childList: true, subtree: true };

    function getMenuItem(id, display, checked){
        var res = '<div><div class="Layout-sc-nxg1ff-0 WUWgS"><div class="Layout-sc-nxg1ff-0 xAfNg"><label class="ScDropDownMenuInputItemLabel-sc-p9ci3m-0 jJaCWO InjectLayout-sc-588ddc-0 fjMXDc tw-drop-down-menu-input-item__label" for="'+id+'">'+display+'</label><div class="ScToggle-sc-796zbf-0 kCtfmS tw-toggle" ><input class="ScToggleInput-sc-796zbf-1 doVmsZ tw-toggle__input" id="'+id+'" type="checkbox" data-a-target="tw-toggle" checked=""><label for="'+id+'" class="ScToggleButton-sc-796zbf-2 oHwVV tw-toggle__button"></label></div></div></div></div>';
        return res;
     }



    function toggleParams() {
        let isReady = $("#displayImages:visible").length > 0;
        if (!isReady) {
            setTimeout(toggleParams, 1000);
            return;
        }
        $("#alwaysSourceQuality").prop("checked",String(alwaysSourceQuality).toUpperCase() == "TRUE");
        $("#displayImages").prop("checked", String(displayImages).toUpperCase() == "TRUE");
        $("#displayVideos").prop("checked",String(displayVideos).toUpperCase() == "TRUE");
        $("#autoPlayClips").prop("checked", String(autoPlayClips).toUpperCase() == "TRUE");
        $("#fixhideOfflineChannels").prop("checked", String(hideOfflineChannels).toUpperCase() == "TRUE");
        $("#fixhideRecommendedChannels").prop("checked", String(hideRecommendedChannels).toUpperCase() == "TRUE");
        $("#hideFriendsList").prop("checked", String(hideFriendsList).toUpperCase() == "TRUE");
        $("#hideHypeTrain").prop("checked", String(hideHypeTrain).toUpperCase() == "TRUE");
        $("#hideBitGiftLeaderBoard").prop("checked", String(hideBitGiftLeaderBoard).toUpperCase() == "TRUE");
        $("#hideUnfollowButton").prop("checked", String(hideUnfollowButton).toUpperCase() == "TRUE");
        $("#hideTags").prop("checked", String(hideTags).toUpperCase() == "TRUE");
        $("#hideSubscribeText").prop("checked", String(hideSubscribeText).toUpperCase() == "TRUE");
        $("#fixhideTheseThots").prop("checked", String(fixhideTheseThots).toUpperCase() == "TRUE");
    }

    function addMenu(){
        if ($(".fixMenuAppended ").length > 0 )
            return;
        var menu = $(".chat-settings__content");
        var isReady = menu.length > 0;
        if (!isReady) {
            setTimeout(addMenu, 50);
            return;
        }
        $('button[data-a-target="chat-settings"]').addClass("fixMenuAppended");


        menu.append('<div class="tw-border-t tw-mg-t-1 tw-mg-x-05 tw-pd-b-1 customEnhanceMenu" ></div><div class="tw-mg-y-05 tw-pd-x-05"><p class="tw-c-text-alt-2 tw-font-size-6 tw-strong tw-upcase" style="color: var(--color-text-alt-2)!important;    font-size: var(--font-size-6)!important;    font-weight: 600!important;    text-transform: uppercase!important;">Enhance Twitch</p></div>');
//alwaysSourceQuality
        menu.append(getMenuItem('alwaysSourceQuality','Always source quality', alwaysSourceQuality));
        $(document).on('change', "#alwaysSourceQuality", function() {
            localStorage.setItem("alwaysSourceQuality", $(this).prop('checked'));
            alwaysSourceQuality = $(this).prop('checked');
            AlwaysSourceQuality();
        });

        menu.append(getMenuItem('displayImages','Display Images', displayImages));
        $(document).on('change', "#displayImages", function() {
            localStorage.setItem("displayImages", $(this).prop('checked'));
            displayImages = $(this).prop('checked');
        });

        menu.append(getMenuItem('displayVideos','Display Videos',displayVideos));
        $(document).on('change', "#displayVideos", function() {
            localStorage.setItem("displayVideos", $(this).prop('checked'));
            displayVideos = $(this).prop('checked');
        });


        menu.append(getMenuItem('autoPlayClips','Auto play clips',autoPlayClips));

        $(document).on('change', "#autoPlayClips", function() {
            localStorage.setItem("autoPlayClips", $(this).prop('checked'));
            autoPlayClips = $(this).prop('checked');
        });

        //hideOfflineChannels

        menu.append(getMenuItem('fixhideOfflineChannels','Hide offline channels',hideOfflineChannels));
         $(document).on('change', "#fixhideOfflineChannels", function() {
            localStorage.setItem("hideOfflineChannels", $(this).prop('checked'));
            hideOfflineChannels = $(this).prop('checked');
        });


        //hideRecommendedChannels
        menu.append(getMenuItem('fixhideRecommendedChannels','Hide Recommended Channels',hideRecommendedChannels));
        $("#fixhideRecommendedChannels").change(function() {
            localStorage.setItem("hideRecommendedChannels", this.checked);
            hideRecommendedChannels = localStorage.getItem("hideRecommendedChannels");
            if (hideRecommendedChannels == "true")
                hideRecommendedChannelsPlease();
            else{
                RemoveCssRule('div[aria-label="Recommended Channels"]');
            }
        });


        //hideRecommendedChannels
        menu.append(getMenuItem('hideFriendsList','Hide Friends',hideFriendsList));
        $("#hideFriendsList").change(function() {
            localStorage.setItem("hideFriendsList", this.checked);
            hideFriendsList = localStorage.getItem("hideFriendsList");
            if (hideFriendsList == "true")
                hideFriends();
            else{
                RemoveCssRule('div[data-a-target="online-friends-list"]');
            }
        });

        menu.append(getMenuItem('hideHypeTrain','Hide hype train',hideHypeTrain));
        $("#hideHypeTrain").change(function() {
            localStorage.setItem("hideHypeTrain", this.checked);
            hideHypeTrain = localStorage.getItem("hideHypeTrain");
            if (hideHypeTrain == "false")
                RemoveCssRule(".community-highlight-stack__scroll-area--disable");
            else
                GM_addStyle(".community-highlight-stack__scroll-area--disable{display: none !important;}");
        });

        menu.append(getMenuItem('hideBitGiftLeaderBoard','Hide gift/bit leaderboard',hideBitGiftLeaderBoard));
        $("#hideBitGiftLeaderBoard").change(function() {
            localStorage.setItem("hideBitGiftLeaderBoard", this.checked);
            hideBitGiftLeaderBoard = localStorage.getItem("hideBitGiftLeaderBoard");
            if (hideBitGiftLeaderBoard == "false")
                RemoveCssRule(".channel-leaderboard");
            else
                GM_addStyle(".channel-leaderboard{display: none !important;}");
        });

        menu.append(getMenuItem('hideUnfollowButton','Hide unfollow button',hideUnfollowButton));
        $("#hideUnfollowButton").change(function() {
            localStorage.setItem("hideUnfollowButton", this.checked);
            hideUnfollowButton = localStorage.getItem("hideUnfollowButton");
            if (hideUnfollowButton == "false")
                RemoveCssRule('button[data-a-target="unfollow-button"] div:first-child');
            else
                GM_addStyle('button[data-a-target="unfollow-button"] div:first-child{width: 0 !important;}');
        });

        //hideTags
        menu.append(getMenuItem('hideTags','Hide tags',hideTags));
        $("#hideTags").change(function() {
            localStorage.setItem("hideTags", this.checked);
            hideTags = localStorage.getItem("hideTags");
            if (hideTags == "false")
                $(".tw-tag").attr("style","display:flex !important");
            else
                $(".tw-tag").attr("style","display:none !important");
        });

        //hideSubscribeText

        menu.append(getMenuItem('hideSubscribeText','Hide (re)subscribe text',hideSubscribeText));
        $("#hideSubscribeText").change(function() {
            localStorage.setItem("hideSubscribeText", this.checked);
            hideSubscribeText = localStorage.getItem("hideSubscribeText");
            if (hideSubscribeText == "false"){
                let btnSub = $('button[data-a-target="subscribe-button"]');
                if (btnSub.length ==0)
                    btnSub = $('button[data-a-target="subscribed-button"]');
                btnSub.find(".tw-mg-l-05").attr("style","display: block !important");
                btnSub.find('div[data-a-target="tw-core-button-label-text"]').attr("style","display: block !important");
            }
            else{
                hideSubButton();
            }
        });
        //hideTheseThots
         menu.append(getMenuItem('fixhideTheseThots','Hide these thots',hideTheseThots));
        $("#fixhideTheseThots").change(function() {
            localStorage.setItem("hideTheseThots", this.checked);
            hideTheseThots = localStorage.getItem("hideTheseThots");
            if (hideTheseThots == "true")
                hideTheseThotsPlease();
            else{
                showTheseThots();
            }
        });

        toggleParams();

    }

    var SupportedImageFormats = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
    var SupportedVideoFormats = [".mp4",".webm"];

    var maxHeight = "240";
    var maxWidth = "300";

    GM_addStyle("iframe[class^='imgur-embed']{max-width: "+maxWidth+"px !important;}");
    GM_addStyle("svg[class*='logotwitchwordmark']{display: none !important;}");
    if (hideHypeTrain == "true")
        GM_addStyle(".community-highlight-stack__scroll-area--disable{display: none !important;}");
    if (hideBitGiftLeaderBoard == "true")
        GM_addStyle(".channel-leaderboard{display: none !important;}");
    GM_addStyle(".btnRefreshEnhance button{height: 15px; width: 100%}");
    GM_addStyle(".chat-settings{    max-height: 500px !important;    overflow: hidden !important;}");

    function isSupportedImage(url) {
        var length = SupportedImageFormats.length;
        while(length--) {
            if (url.indexOf(SupportedImageFormats[length])!=-1) {
                return true;
            }
        }
        return false;
    }
    function isSupportedVideo(url) {
        var length = SupportedVideoFormats.length;
        while(length--) {
            if (url.indexOf(SupportedVideoFormats[length])!=-1) {
                return true;
            }
        }
        return false;
    }

    function alterNode(node) {
        var thisUrl = $(node).text();
        if (displayImages == "true" && isSupportedImage(thisUrl)){
            $(node).html("<br><img src='" + thisUrl + "' width='" + maxWidth +"px'/>");
            $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
        }
        else if (displayVideos == "true" && thisUrl.indexOf("www.youtube") > 0 ){
            if (thisUrl.indexOf("watch") > 0){
                var videoId  = thisUrl.match('v=([^&]*)')[1];
                $(node).html('<br><iframe width="'+ maxWidth +'" height="'+ maxHeight +'" src="https://www.youtube.com/embed/' + videoId+'"></iframe>');
                $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
            }
        }
        else if (displayVideos == "true" && isSupportedVideo(thisUrl)){
            $(node).html('<br><video width="'+ maxWidth +'" height="'+ maxHeight +'" controls autoplay muted><source src="'+thisUrl +'" type="video/mp4"></video>');
            $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
        }
        else if (displayImages == "true" && thisUrl.indexOf("https://gyazo.com") > -1 ){
            $(node).html("<br><img src='" + thisUrl.replace("https://gyazo.com", "https://i.gyazo.com") +".png' width='" + maxWidth +"px'/>");
            $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');

        }
        else if (displayImages == "true" && thisUrl.indexOf("imgur") > -1){
            var imgurId = "";
            if (thisUrl.indexOf("gallery") > -1){
                imgurId = thisUrl.match('gallery\/([^#]*)')[1];
                try{
                    $(node).html('<div style="width:200"><blockquote class="imgur-embed-pub" lang="en" data-id="a/'+ imgurId +'"><a href="//imgur.com/'+ imgurId +'" ></a></blockquote><script async src="//s.imgur.com/min/embed.js" charset="utf-8"></script></div>');
                    $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
                }
                catch(err){
                }
            }
            else{
                imgurId = thisUrl.match('a\/([^#]*)')[1];
                try{
                    $(node).html('<div style="width:200"><blockquote class="imgur-embed-pub" lang="en" data-id="a/'+ imgurId +'"><a href="//imgur.com/'+ imgurId +'" ></a></blockquote><script async src="//s.imgur.com/min/embed.js" charset="utf-8"></script></div>');
                    $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
                }
                catch(err){
                }
            }
            parentToScroll.animate({scrollTop:parentToScroll.scrollTop() + 500}, 'slow');
        }
        else if (displayVideos == "true" && thisUrl.indexOf("clips.twitch.tv") > -1){
            var clipId = thisUrl.match('.tv\/(.*)')[1];
            $(node).html('<iframe src="https://clips.twitch.tv/embed?clip='+clipId+'&autoplay='+autoPlayClips+'&muted=true&parent=twitch.tv" frameborder="0"   allowfullscreen="true" height="'+maxHeight+'" width="'+maxWidth+'"></iframe>');
            $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
        }
        else if (displayVideos == "true" && thisUrl.indexOf("twitch") > -1 && thisUrl.indexOf("clip") > -1){
            var clipId1 = thisUrl.match('clip\/([^?]*)')[1];
            $(node).html('<iframe src="https://clips.twitch.tv/embed?clip='+clipId1+'&autoplay='+autoPlayClips+'&muted=true&parent=twitch.tv" frameborder="0"   allowfullscreen="true" height="'+maxHeight+'" width="'+maxWidth+'"></iframe>');
            $(".enhanceAppended").find('.simplebar-scroll-content').animate({scrollTop:$(".enhanceAppended").find('.simplebar-scroll-content').scrollTop() + 1000}, 'fast');
        }
    }
    // Callback function to execute when mutations are observed
    var callback = function(mutationsList, observer) {
        for(var mutation of mutationsList)  {
            mutation.addedNodes.forEach(function(node) {
                if (node.classList != undefined && node.classList.contains('link-fragment')) {
                    alterNode(node);
                }
                if (node.querySelectorAll){
                    node.querySelectorAll('.link-fragment').forEach(function(node) {
                        alterNode(node);
                    })
                    node.querySelectorAll('.text-fragment').forEach(function(node) {
                        alterNode(node);
                    })
                }
            });
        }
    };

    var callbackAddMenu = function(mutationsList, observer) {
        $('button[data-a-target="chat-settings"]:not(.fixMenuAppended)').click(function(){
            addMenu();
        });
    };
    var callbackClaim = function(mutationsList, observer) {
        for(var mutation of mutationsList) {
            $(".claimable-bonus__icon").click();
        }
    };


    var observerMenu = new MutationObserver(callbackAddMenu);
    // Create an observer instance linked to the callback function
    var observer = new MutationObserver(callback);
    function _appendObserver() {
        let isReady = $("div.chat-list--default").length > 0;
        if (!isReady) {
            setTimeout(_appendObserver, 500);
            return;
        }
        if (!$("div.chat-list--default").hasClass("enhanceAppended")){
            $("div.chat-list--default").addClass("enhanceAppended");
            var targetNode = $("div.chat-list--default").get(0);
            var targetNode2 = $(".chat-room").get(0);
            // Start observing the target node for configured mutations
            if (targetNode2 != undefined){
                observerMenu.observe(targetNode2, config);
            }
            if(targetNode !=undefined){
                observer.observe(targetNode, config);
            }
        }
    }
    _appendObserver();

    var targetNodeRoot = document.getElementById('root');
    var configRoot = { attributes: false, childList: true, subtree: true };

    var callbackRoot = function(mutationsList, observer) {
        $(".claimable-bonus__icon").click();
        _appendObserver();
        if (hideTags == "true")
            $(".tw-tag").attr("style","display:none !important");
        if (hideOfflineChannels == "true"){
            for(var mutation of mutationsList){
                mutation.addedNodes.forEach(function(node) {
                    //side-nav-card__avatar
                    var channelStatus = $(node).find(".side-nav-card__avatar");
                    var offlineChannels = $(node).find(".side-nav-card__avatar--offline");
                    if (offlineChannels.length > 0){
                        var parentStatus = offlineChannels.parent();
                        parentStatus.attr("style","display:none !important;");
                    }
                    if (channelStatus.length > 0){
                        var elemToObserve = channelStatus.get(0);
                        var observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                var channelIsOffline = mutation.target.classList.contains('side-nav-card__avatar--offline');
                                var parentStatus = $($(mutation)[0].target).parent();
                                if(channelIsOffline){
                                    parentStatus.attr("style", "display:none !important;");
                                }
                                else{
                                    parentStatus.attr("style","display:inherit !important;");
                                    $('button[data-test-selector="ShowMore"]').click();
                                }
                            });
                        });
                        observer.observe(elemToObserve, {attributes: true});
                    }
                });
            }
        }

        if (window.location.href == "https://www.twitch.tv/"){
            var videoMainPage = $(".featured-content-carousel:not(.fixVideoPausedOnce)").find("video");
            if (videoMainPage.length > 0){
                videoMainPage.get(0).pause();
                videoMainPage.parent().click(function(){
                    $(".featured-content-carousel").addClass('fixVideoPausedOnce');
                });
            }
        }

        var linkArg = $(".about-section__panel--content").find(".tw-title").text().replace("About ","");
        if ($(".about-section__panel--content:not(.fixLinksAppended)").length > 0 || $(".about-section__panel--content").attr("id") != "fix" + linkArg){
            var appendable = $(".about-section__panel--content").find('.tw-title').parent();
            if (appendable.length>0) {
                $("#fixVideosLinks").remove();
                $("#fixClipsLinks").remove();
                $("#fixSpanLinks").remove();
                appendable.parent().append('<a target="_blank" id ="fixVideosLinks" href="/'+linkArg+'/videos"><span>Videos</span></a><span id = "fixSpanLinks"> / </span>');
                appendable.parent().append('<a target="_blank" id ="fixClipsLinks" href="/'+linkArg+'/clips?filter=clips&range=7d"><span>Clips</span></a>');
                $(".about-section__panel--content").addClass("fixLinksAppended");
                $(".about-section__panel--content").attr("id","fix"+linkArg);
                if (hideTags == "true")
                    $(".tw-tag").attr("style","display:none !important");
                if(hideSubscribeText == "true"){
                    hideSubButton();
                }
                if (hideUnfollowButton == "true")
                    GM_addStyle('button[data-a-target="unfollow-button"] div:first-child{width: 0 !important;}');
            }
        }
    };

    // Create an observer instance linked to the callback function
    var observerroot = new MutationObserver(callbackRoot);

    // Start observing the target node for configured mutations
    observerroot.observe(targetNodeRoot, config);

    var callbackQuality = function(mutationsList, observer) {
        localStorage.setItem('video-quality', '{"default":"chunked"}');
    };

    function _appendQualityObserver() {
        var isReady = $('div[data-a-target="player-controls"]').length > 0;
        if (!isReady) {
            setTimeout(_appendQualityObserver, 500);
            return;
        }
        var targetNodeQuality = $('div[data-a-target="player-controls"]').get(0);
        var observerQuality = new MutationObserver(callbackQuality);
        observerQuality.observe(targetNodeQuality, config);
    }

    function hideRecommendedChannelsPlease(){
        GM_addStyle('div[aria-label="Recommended Channels"]{    display:none !important;}');
    }

    function hideFriends(){
        GM_addStyle('div[data-a-target="online-friends-list"]{    display:none !important;}');
    }

    if (hideRecommendedChannels == "true"){
        hideRecommendedChannelsPlease();
    }
    if (hideFriendsList == "true"){
        hideFriends();
    }

     function   hideTheseThotsPlease(){
         //alert("hiding these thots");
     };
     function showTheseThots(){
         //alert("showing these thots");
     }

}

(function() {
    'use strict';
    LoadTwitchEnhance();
})();